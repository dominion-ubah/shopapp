// export class Product {
// }

export const ProductList =



     [
            {
                'id': '1',
                'name': 'Vegetables',
                'price': 2,
                'main_image': 'http://via.placeholder.com/150x150',
                'currency': '$',
                'images': 'http://via.placeholder.com/150x150',
                'type': 'new',
                'categories': '.mlknbjvhcgfxdzxfcgvhbjnkml'
            },
            {
                'id': '2',
                'name': 'Rice',
                'price': 5,
                'main_image': 'http://via.placeholder.com/150x150',
                'currency': '$',
                'images': 'http://via.placeholder.com/150x150',
                'type': 'new',
                'categories': '.mlknbjvhcgfxdzxfcgvhbjnkml'
            },
            {
                'id': '3',
                'name': 'Apples',
                'price': 2,
                'main_image': 'http://via.placeholder.com/150x150',
                'currency': '$',
                'images': 'http://via.placeholder.com/150x150',
                'type': 'new',
                'categories': '.mlknbjvhcgfxdzxfcgvhbjnkml'
            },
            {
                'id': '4',
                'name': 'Sausages',
                'price': 8,
                'main_image': 'http://via.placeholder.com/150x150',
                'currency': '$',
                'images': 'http://via.placeholder.com/150x150',
                'type': 'new',
                'categories': '.mlknbjvhcgfxdzxfcgvhbjnkml'
            },
            {
                'id': '5',
                'name': 'Chicken',
                'price': 2,
                'main_image': 'http://via.placeholder.com/150x150',
                'currency': '$',
                'images': 'http://via.placeholder.com/150x150',
                'type': 'old',
                'categories': '.mlknbjvhcgfxdzxfcgvhbjnkml'
            },
            {
                'id': '6',
                'name': 'Eggs',
                'price': 2,
                'main_image': 'http://via.placeholder.com/150x150',
                'currency': '$',
                'images': 'http://via.placeholder.com/150x150',
                'type': 'old',
                'categories': '.mlknbjvhcgfxdzxfcgvhbjnkml'
            }
            ];
